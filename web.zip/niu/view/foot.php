
<div id="foot" style="padding-bottom: 160px;">
    <div class="footer">
        <div class="area"><?php echo mi("警告：如果您未满18岁或您当地法律许可之法定年龄、或是对情色反感或是卫道人士建议您离开本站！"); ?></div>
        <div class="area"><font color="#fff"><?php echo mi(htmlspecialchars_decode($cfg["contat"])); ?></font></div>
    </div>
</div>

<div id="topNavad">
    <div id="MyDiv2">
        <div id="newsImg">
            <center><?php echo getad(6); ?></center>
        </div>
        <span onclick="CloseDiv('MyDiv2')" style="color:#fff;text-align:right; display:block;"><?php echo mi("关闭"); ?></span>
    </div>
</div>
<div id="bottomNavad">
    <div id="MyDiv1"> 
        <span onclick="CloseDiv('MyDiv1')" style="color:#fff;text-align:right; display:block;"><?php echo mi("关闭"); ?></span>
        <center><?php echo getad(7); ?></center>
    </div>
</div> 
<div id="float_right" class="float float_right">
    <ul>
        <?php echo getAd(8); ?>
    </ul>
</div>
 
</main>
<script src="/static/lazy/lazyload.min.js"></script>    
<script>
    function CloseDiv(div) {
        document.getElementById(div).style.display = 'none';
    };
    lazyload();

</script> 
