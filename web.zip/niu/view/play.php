<?php         
    $yuanid = get('yuanid'); 
    $id = get('id');     
    $A = $db->query(" select * from `n_1_form_video` where `id` = $id  ") ;       
    $A =  $A[0];     
    require_once("head.php");    
    
    if($id < OLDID){
        $videohost = "https://play.ldsdebofangnewest.com";
        $imghost = "https://play.dzspyw.com";
    }else{
        $videohost = $cfg['videohost'];
        $imghost = $cfg['imghost'];
    }
?>    

<h2 style="text-align: center; margin: 20px 10px 10px;font-size: 18px;"><?php echo mi($A['title']); ?></h2>
<!-- player -->
<div class="play_main">
    <div class="play_box">
        <video id="myVideo" class="video-js vjs-default-skin vjs-big-play-centered vjs-16-9" controls="controls" preload="auto" poster="<?php echo $imghost . $A['litpic']; ?>" data-setup='{"fluid": true}'>
            <source id="source" src="<?php echo $videohost . $A['address']."/index.m3u8"; ?>" type="application/x-mpegURL"></source>
        </video>
    </div>

    <div style="background-color: #333333; border-radius: 3px; padding: 3px 5px 3px 5px; text-align: center;">
        <div class="tag-list">
            <?php 
                $tagArr = explode("|",$A['tags']);              
                foreach($tagArr as $k=>$v){
                    echo ' <a target="<?php echo TARGET;?>" style="color:#008000"  href="/find/'.urlencode($v).'">' . mi($v) . '</a>&nbsp;&nbsp;';
                }
            ?>
        </div>

        <div style="padding: 10px 0;" class="btn-line">
            <a target="<?php echo TARGET;?>" href="javascript:;" data-line="0" class="layui-btn layui-bg-purple btn-select line-0"><?php echo mi("▶️ 默认线路"); ?></a>&nbsp;&nbsp;
            <a target="<?php echo TARGET;?>" href="javascript:;" data-line="1" class="layui-btn layui-btn-normal"><?php echo mi("备用线路"); ?></a>&nbsp;&nbsp;
        </div>
        <div class="playfabu">
            <?php            
                echo htmlspecialchars_decode($cfg["fabu"]);                  
            ?>      
        </div>
    </div>
</div>
<!-- player -->





<div class="caption x m">
    <div><?php echo mi("猜你喜欢"); ?></div>
    <div class="lr"></div>  
    <div><a target="<?php echo TARGET;?>" href="/new"><?php echo mi("更多最新>>"); ?></a></div>
</div>

<div class="vlist layui-row layui-col-space10">

<?php   

  $ads = getad(5); 
    $num = 24 - count($ads);
    

$tagArr = explode("|",$A['tags']);  
    if(count($tagArr) > 0){
        $sql = " select `litpic`, `title`, `inputtime`, `id`,`click`,`type`,  ";
    
        $titleSql = " ";
        $tagsSql = ""; 
        foreach($tagArr as $k=>$v){
            $titleSql .= " (CASE WHEN title LIKE '%".$v."%' THEN 1 ELSE 0 END) +";
            $tagsSql = " (CASE WHEN tags LIKE '%".$v."%' THEN 2 ELSE 0 END) +"; 
        }
    
        $tagsSql = rtrim($tagsSql,"+");
    
        $sql .= $titleSql.$tagsSql ." AS relevance FROM `n_1_form_video` where  `zt` = 1  and id <> '".$A['id']."' ORDER BY relevance DESC  limit  $num; "; //and id <> '".$A['id']."'
    }else{
        $sql = " select `litpic`, `title`, `inputtime`, `id`,`click`,`type` FROM `n_1_form_video` where  `zt` = 1  order by RAND() limit  $num ";
    }
 
   

   // var_dump($sql);
?>        

<?php
    // 模拟SQL查询
    $result = $db->query($sql); 
    $key = 0;
    foreach ($result as $t) { 
        if ($key == 0) {
            $ads = getad(5);  
            $numArr = array();
            if($ads){
                $numArr = randNums(0, 12, count($ads)); 
            }        
        }
      
        if (in_array($key, $numArr)) {    
            echo $ads[0];
            array_shift($ads);
        }
        
         if($t['id'] < OLDID){
        $imghost = "https://play.dzspyw.com";
    }else{
        $imghost =  $cfg['imghost'];
    }
    
?>

<div class="vone layui-col-sm4 layui-col-xs6">
    <dl>
        <dt class="preview-item">
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><img class="lazyload" data-src="<?php echo $imghost; ?><?php echo $t['litpic']; ?>" ><i></i>
                <div class="preview-div"></div>
            </a>
          
            <div class="view-times">
                <div class='views'>
                <?php
                    if($t['click'] > 1000){
                        echo "<span></span>". number_format($t['click'], 0, '', ',') ;
                    }
                ?>
                </div>
                    
                <div class="date"><?php echo date("m-d",$t['inputtime']); ?></div>
            </div>

        </dt>
        <dd>
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><h3 class="showenc"><?php echo mi($t['title']); ?></h3></a>
        </dd>
    </dl>
</div> 

<?php 
        $key++; 
    } // foreach结束
?>

<div class="clear"></div>
</div>





<div class="caption x m">
    <div><?php echo mi("热门必看"); ?></div>
    <div class="lr"></div>  
    <div><a target="<?php echo TARGET;?>" href="/hot"><?php echo mi("更多热门>>"); ?></a></div>
</div>

<div class="vlist layui-row layui-col-space10">

<?php   
    $todayStart = strtotime("today midnight");
    $stime = $todayStart - 86400 * 31 * rand(10,365); 
    //$sql = 'select `litpic`, `title`, `inputtime`, `id`,`click` from `n_1_form_video` where  `zt` = 1  and inputtime > ' . $stime . ' order by `click` desc limit 24';     
    $clickNum = rand(1000000,1100000);
    $sql = "select `litpic`,`title`,`inputtime`,`id`,`click`,`type` from `n_1_form_video` where `zt` = 1 and click > $clickNum order by rand() limit 24";

   // var_dump($sql);
?>        

<?php
    // 模拟SQL查询
    $result = $db->query($sql); 
    $key = 0;
    foreach ($result as $t) { 
        if ($key == 0) {
            $ads = getad(5);  
            $numArr = array();
            if($ads){
                $numArr = randNums(0, 12, count($ads)); 
            }        
        }
      
        if (in_array($key, $numArr)) {    
            //echo $ads[0];
            array_shift($ads);
        }
        
        
           if($t['id'] < OLDID){
        $imghost = "https://play.dzspyw.com";
    }else{
        $imghost =  $cfg['imghost'];
    }
    
?>

<div class="vone layui-col-sm4 layui-col-xs6">
    <dl>
        <dt class="preview-item">
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><img class="lazyload" data-src="<?php echo $imghost; ?><?php echo $t['litpic']; ?>" ><i></i>
                <div class="preview-div"></div>
            </a>
            <div class="view-times">
                <div class='views'>
                <?php
                    if($t['click'] > 1000){
                        echo "<span></span>". number_format($t['click'], 0, '', ',') ;
                    }
                ?>
                </div>
                    
                <div class="date"><?php echo date("m-d",$t['inputtime']); ?></div>
            </div>

         
        </dt>
        <dd>
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><h3 class="showenc"><small><?php echo $t['type']; ?></small><?php echo mi($t['title']); ?></h3></a>
        </dd>
    </dl>
</div> 

<?php 
        $key++; 
    } // foreach结束
?>

<div class="clear"></div>
</div>



<div class="adqu">
    <div class="links-top wrapper">
        <ul class="icon-list">
            <?php echo getad(4); ?>                             
        </ul>
    </div>  
</div>

<div class="m10" style="height: 20px;"></div>

<link href="/static/video-js-7.4.1/video-js.min.css" rel="stylesheet" /> 
<script src="/static/video-js-7.4.1/video.min.js"></script>
<script src="/static/video/videojs-contrib-hls.min.js" type="text/javascript"></script> 
          
<script type="application/javascript">
    $(function(){

        var myVideo = videojs('myVideo', {
            bigPlayButton: true,
            textTrackDisplay: false,
            posterImage: false,
            errorDisplay: false,
            autoplay: false
        });
        var changeVideo = function (vdoSrc) {
            if (/\.m3u8$/.test(vdoSrc)) {  
                myVideo.src({
                    src: vdoSrc,
                    type: 'application/x-mpegURL' 
                });
            } else {
                myVideo.src(vdoSrc);
            }
            myVideo.load();
            myVideo.play();
        };
        var playurl_default = '<?php echo $videohost . $A['address']; ?>/index.m3u8';
        var playurl_bak = '<?php echo $videohost. $A['address']; ?>/index.m3u8';
        
        myVideo.on('error', function() {
            myVideo.src(playurl_default);
            myVideo.play();  
        });

        $(document).on('click', '#video-ads, #gg-close', function() {
            $(".video-ads").addClass('hidden');
        });

        $(document).on("click",".btn-line a",function(){
            var lineSelected = $(this).attr('data-line');
            $(this).addClass('btn-select').removeClass('btn-default').siblings().removeClass('btn-select').addClass('btn-default');
            $(".video-ads").hide();
            currentTime = myVideo.currentTime();
            lineSelected == 1 ? changeVideo(playurl_bak) : changeVideo(playurl_default);
            myVideo.currentTime(currentTime);
        });
    });


    $.get("/?a=click&id=<?php echo $id; ?>&v=<?php echo time(); ?>",{ },function(result){
        //console.log(result);
    });

</script>

 

<?php
  require_once( "foot.php");
?>