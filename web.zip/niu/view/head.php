<main>      
<div class="adqu topad">
    <?php echo getad(6); ?>
</div> 
<div id="area" class="logoqu hei x m">
    <span> <a target="<?php echo TARGET;?>" href="/"> 
        <img src="/static/logo.png" > 
    </a></span>    
    <span>
        <a target="<?php echo TARGET;?>" href="/"><?php echo mi("首页"); ?></a>
    </span>     
</div> 
<div class="adqu adhf">
    <?php echo getad(1); ?>
</div>
<div class="adqu">
    <div class="menu-wrap">
        <?php echo getad(2); ?>
        <div class="clear"></div>
    </div>   
</div>
<a target="<?php echo TARGET;?>" name="type"></a>
<div id="menu">
    <div class="x">
        <div class="c m" style="width: 60px; text-align: center; font-weight: bold;">
            <?php echo mi("本站"); ?><br><?php echo mi("导航"); ?> 
        </div>
        <div class="menua layui-row lr">
            <?php
            $query = " select count(id) as dd,type from n_1_form_video where zt = 1 group by type order by dd desc ";
            $menuItems = $db->query($query); // 查询数据库                
            foreach ($menuItems as $t) {
                if(empty($t['type'])){
                    continue;
                }
                ?>
           
                <a target="<?php echo TARGET;?>"  href="/video/<?php echo jjStr2Hex($t['type']); ?>" class="layui-col-sm4 layui-col-xs4">           
                <img class="hotimg" src="/static/icon-hot.gif"> <span><?php echo mi($t['type']); ?></span>
                </a> 
            <?php } ?>
        </div>
    </div> 
</div>
<div class="adqu">
    <div class="menu-wrap">
        <?php echo getad(3); ?>
        <div class="clear"></div>
    </div>   
</div>

<div id="search">
    <form action="#" method="post" name="searchform" id="searchform" onsubmit="return search()">
        <div class="x">
            <div class="lr">
                <input name="q" id="s_word" type="text" class="inputText" value="<?php echo mi(get('q')); ?>" placeholder="<?php echo mi('AV番号/AV女优/AV标签'); ?>"> 
            </div>
            <div>
                <input type="submit" id="searchVod" class="layui-btn layui-bg-red" value="<?php echo mi('视频搜索'); ?>">
            </div>
        </div>   
        

        
        <div class="reso">热搜:<?php     

    $numArr = randNums(0, 100, 15); 
    
 

    $arr = $db->query("select `tags`  from `n_1_form_video` where  `zt` = 1 and tags <> '' ");   
    $reso = array();
    foreach($arr as $k=>$v){
       
        $brr = explode("|",$v['tags']);
        foreach($brr as $n=>$m){
            if(array_key_exists( $m, $reso )){
                 $reso[$m] ++ ; 
            }else{
                 $reso[$m] = 0 ;
            }
          
        }
    }
     arsort($reso);
     $i = 0;
     foreach($reso as $k=>$v){
        
        if (in_array($i, $numArr)) {    
              echo '<a href="/find/'.urlencode($k).'" target="'.TARGET.'">'.$k.'</a>';
        }
        $i++;
         if( $i > 100){
             break;
         }
     }
         
?>
        
        </div>
    </form>
    <script>
        function search(){    
            window.location.href = "/find/" + $("#s_word").val();
            return false;
        }
    </script>
</div>
<div class="adqu">
    <div class="links-top wrapper">
        <ul class="icon-list">
            <?php echo getad(4); ?>                             
        </ul>
    </div>  
</div>
 