<?php
    $cfg = require FUNC_DIR.'config.php';  
?><!DOCTYPE html><html lang="en"><head><title></title><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><link href="/static/my.css" rel="stylesheet"><script src="/static/jquery.min.js" type="text/javascript"></script><?php 
echo compress_js(htmlspecialchars_decode($cfg["qjtjdm"]));
?></head><body>