<?php  
    $yuanid = get('yuanid'); 
    $id = get('id');   
    $A = $db->query(" select * from `n_1_form_video` where `id` = $id  ") ;       
    $A =  $A[0];   
    require_once("head.php");  
    if($id < OLDID){
        $cfg['videohost'] = "https://play.ldsdebofangnewest.com";
        $cfg['imghost'] = "https://play.dzspyw.com";
    }
   
?>    
 
<div class="showVideo" style="overflow: hidden; width: 100%; height: auto; text-align: center;">
    <div><a  href="/video/play/<?php echo $yuanid; ?>.html"><img class="lazyload" data-src="<?php echo $cfg['imghost'].$A['litpic']; ?>" style="width: 100%; height: auto; display: inline;" ></a></div>
    <p class="tag-list">
        <?php 
            $arr = explode("|",$A['tags']);             
            foreach($arr as $k => $v) {
                echo ' <a target="<?php echo TARGET;?>" style="color:#008000"  href="/find/'.urlencode($v).'">' . mi($v) . '</a>&nbsp;&nbsp;';
            }
        ?>
    </p>
    <div>
        <div>
            <h3 style="color: #333333; padding-top: 8px;" class="showenc"><?php echo mi($A['title']); ?></h3>
        </div>
        <div style="padding: 20px 0 20px 0;" id="detail-btn">
            <a  href="/video/play/<?php echo $yuanid; ?>.html" class="layui-btn layui-bg-blue"><?php echo mi("▶ 在线播放"); ?></a>&nbsp;&nbsp;

            <span class="adqu">  <?php echo getad(9); ?> </span>                                                                     
        </div>
        <div class="showfabu">
            <?php            
                echo htmlspecialchars_decode($cfg["fabu"]);                  
            ?>     
        </div>
    </div>
</div>



<div class="caption x m">
    <div><?php echo mi("猜你喜欢"); ?></div>
    <div class="lr"></div>  
    <div><a target="<?php echo TARGET;?>" href="/new"><?php echo mi("更多最新>>"); ?></a></div>
</div>

<div class="vlist layui-row layui-col-space10">

<?php   

    $ads = getad(5); 
    $num = 24 - count($ads);
    
    
    
    $tagArr = explode("|",$A['tags']);  
    if(count($tagArr) > 0){
        $sql = " select `litpic`, `title`, `inputtime`, `id`, `click`,`type`,  ";
    
        $titleSql = " ";
        $tagsSql = ""; 
        foreach($tagArr as $k=>$v){
            $titleSql .= " (CASE WHEN title LIKE '%".$v."%' THEN 1 ELSE 0 END) +";
            $tagsSql = " (CASE WHEN tags LIKE '%".$v."%' THEN 2 ELSE 0 END) +"; 
        }
    
        $tagsSql = rtrim($tagsSql,"+");
    
        $sql .= $titleSql.$tagsSql ." AS relevance FROM `n_1_form_video` where  `zt` = 1  and id <> '".$A['id']."' ORDER BY relevance DESC  limit  $num ; "; //and id <> '".$A['id']."'
    }else{
        $sql = " select `litpic`, `title`, `inputtime`, `id`,`click`, `type` FROM `n_1_form_video` where  `zt` = 1   order by RAND() limit  $num  ";
    }

  
?>        

<?php
    // 模拟SQL查询
    $result = $db->query($sql); 
    $key = 0;

    foreach ($result as $t) { 
        if ($key == 0) {
            
            $numArr = array();
            if($ads){
                $numArr = randNums(0, 12, count($ads)); 
            }        
        }
      
        if (in_array($key, $numArr)) {    
            echo $ads[0];
            array_shift($ads);
        }
        
         if($t['id'] < OLDID){
        $imghost = "https://play.dzspyw.com";
    }else{
        $imghost =  $cfg['imghost'];
    }
    
?>

<div class="vone layui-col-sm4 layui-col-xs6">
    <dl>
        <dt class="preview-item">
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><img class="lazyload" data-src="<?php echo $imghost; ?><?php echo $t['litpic']; ?>" ><i></i>
                <div class="preview-div"></div>
            </a>
          
            <div class="view-times">
                <div class='views'>
                <?php
                    if($t['click'] > 1000){
                        echo "<span></span>". number_format($t['click'], 0, '', ',') ;
                    }
                ?>
                </div>
                    
                <div class="date"><?php echo date("m-d",$t['inputtime']); ?></div>
            </div>

        </dt>
        <dd>
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><h3 class="showenc"><?php echo mi($t['title']); ?></h3></a>
        </dd>
    </dl>
</div> 

<?php 
        $key++; 
    } // foreach结束
?>

<div class="clear"></div>
</div>





<div class="caption x m">
    <div><?php echo mi("热门必看"); ?></div>
    <div class="lr"></div>  
    <div><a target="<?php echo TARGET;?>" href="/hot"><?php echo mi("更多热门>>"); ?></a></div>
</div>

<div class="vlist layui-row layui-col-space10">

<?php   
    $todayStart = strtotime("today midnight");
    $stime = $todayStart - 86400 * 31 * rand(10,365); 
    //$sql = 'select `litpic`, `title`, `inputtime`, `id`,`click` from `n_1_form_video` where  `zt` = 1  and inputtime > ' . $stime . ' order by `click` desc limit 24';   
    
    $clickNum = rand(1000000,1100000);
    $sql = "select `litpic`,`title`,`inputtime`,`id`,`click`,`type` from `n_1_form_video` where `zt` = 1 and click > $clickNum order by rand() limit 24";

 
   // var_dump($sql);
?>        

<?php
    // 模拟SQL查询
    $result = $db->query($sql); 
    $key = 0;
    foreach ($result as $t) { 
        if ($key == 0) {
            $ads = getad(5);  
            $numArr = array();
            if($ads){
                $numArr = randNums(0, 17, count($ads)); 
            }        
        }
      
        if (in_array($key, $numArr)) {    
            //echo $ads[0];
            array_shift($ads);
        }
        
        
        if($t['id'] < OLDID){
        $imghost = "https://play.dzspyw.com";
    }else{
        $imghost =  $cfg['imghost'];
    }
    
    
?>

<div class="vone layui-col-sm4 layui-col-xs6">
    <dl>
        <dt class="preview-item">
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><img class="lazyload" data-src="<?php echo $imghost; ?><?php echo $t['litpic']; ?>" ><i></i>
                <div class="preview-div"></div>
            </a>
            <div class="view-times">
                <div class='views'>
                <?php
                    if($t['click'] > 1000){
                        echo "<span></span>". number_format($t['click'], 0, '', ',') ;
                    }
                ?>
                </div>
                    
                <div class="date"><?php echo date("m-d",$t['inputtime']); ?></div>
            </div>

         
        </dt>
        <dd>
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><h3 class="showenc"><small><?php echo $t['type']; ?></small><?php echo mi($t['title']); ?></h3></a>
        </dd>
    </dl>
</div> 

<?php 
        $key++; 
    } // foreach结束
?>

<div class="clear"></div>
</div>



<div class="adqu">
    <div class="links-top wrapper">
        <ul class="icon-list">
            <?php echo getad(4); ?>                             
        </ul>
    </div>  
</div>

<div class="m10" style="height: 20px;"></div>
<script>
    $.get("/?a=click&id=<?php echo $id; ?>&v=<?php echo time(); ?>",{ },function(result){
        //console.log(result);
    });
</script>
<?php
  require_once( "foot.php");
?>