<?php
include_once(dirname(__FILE__)."/../func/page.php");   
require_once("head.php");     
?>

<div class="caption x m">
    <div><?php echo mi("最新视频"); ?>   </div>
    <div class="lr"></div>      
</div>
<div class="vlist layui-row layui-col-space10">
<?php
    $page = get("page")  ;
    if (empty($page)) {
        $page = 1;
    }   
    $pagesize = 24;
    $s = ($page - 1) * $pagesize ;
    $query = 'select `litpic`,`title`,`inputtime`,`id`,`click`,`type` from `n_1_form_video` where  `zt` = 1   order by `inputtime` desc limit '.$s.", ".$pagesize;
    $urlrule = "/new/p[page]";     
?>        

<?php

 
    // 模拟SQL查询
    $result =  $db->query($query);

 
    
    $ads = getad(5);  
    foreach($ads as $k=>$v){
        echo $v;
    }

    foreach ($result as $t) { 

    if($t['id'] < OLDID){
        $imghost = "https://play.dzspyw.com";
    }else{
        $imghost =  $cfg['imghost'];
    }

?>

<div class="vone layui-col-sm4 layui-col-xs6">
    <dl >
        <dt class="preview-item">
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><img class="lazyload" data-src="<?php echo $imghost; ?><?php echo $t['litpic']; ?>"  ><i></i>
                <div class="preview-div"></div>
            </a>
            <div class="view-times">
                        <div class="views"> <?php
                            if($t['click'] > 100){
                                echo "<span></span>". number_format($t['click'], 0, '', ',') ;
                            }
                        ?></div>
                        <div class="date"><?php echo date("m-d",$t['inputtime']); ?></div>
                  </div>
                   
        </dt>
        <dd>
            <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html"  title="<?php echo $t['title']; ?>"><h3 class="showenc"><small><?php echo $t['type']; ?></small><?php echo mi($t['title']); ?></h3></a>
        </dd>
    </dl>
</div> 

<?php 
    } // foreach结束
?>
<div class="clear"></div>

</div>  

<div id="page">
<?php      
    $A = $db->query(" select count(*) as dd from  `n_1_form_video` where  `zt` = 1  ") ;    
    $totalRecords = $A[0]['dd']; // 这里设置总记录数 
    $currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $pagination = new Pagination($totalRecords, $pagesize, $currentPage);
    echo $pagination->generateLinks('/new/');
?>
</div>

<div class="m10" style="height: 20px;"></div>
<?php
  require_once( "foot.php");
?>