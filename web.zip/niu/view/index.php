<?php    
    require_once("head.php");  
?>   

<div id="content">
    <div class="caption x m">
        <div><a target="<?php echo TARGET;?>" href="/new"><?php echo mi("最新视频"); ?></a></div>
        <div class="lr"></div>
        <div><a target="<?php echo TARGET;?>" href="/new"><?php echo mi("更多>>"); ?></a></div>
    </div>
    <div class="vlist layui-row layui-col-space10">   
        <?php   
            $ads = getad(5);  
            $num = 24 - count($ads);
            $arr = $db->query('select `litpic`,`title`,`inputtime`,`id`,`click`,`type` from `n_1_form_video` where  `zt` = 1 order by `inputtime` desc limit '.$num);    
            foreach($ads as $k=>$v){
                echo $v;
            }
            foreach($arr as $k=>$t){ 
                
                
            if($t['id'] < OLDID){
                $imghost = "https://play.dzspyw.com";
            }else{
                $imghost =  $cfg['imghost'];
            }
    
    
        ?>
        <div class="vone layui-col-sm4 layui-col-xs6">
            <dl >
                <dt class="preview-item">         
                    <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><img class="lazyload" data-src="<?php echo $imghost. $t['litpic']; ?>"  ><i></i>
                        <div class="preview-div"></div>
                    </a>                   
                    <div class="view-times">
                <div class='views'>
                <?php
                    if($t['click'] > 1000){
                        echo "<span></span>". number_format($t['click'], 0, '', ',') ;
                    }
                ?>
                </div>
                    
                <div class="date"><?php echo date("m-d",$t['inputtime']); ?></div>
            </div>

                </dt>
                <dd>
                    <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><h3 class="showenc"> <small><?php echo $t['type']; ?></small> <?php echo mi($t['title']); ?></h3></a>
                </dd>
            </dl>
        </div> 
        <?php 
        }
        ?>
 
        <div class="clear"></div>
    </div> 
    </div>
    </div>
    <div id="loading" style="display:none; text-align:center; padding:8px;"><img src="/static/loading.gif" /></div>
    <script>
$(document).ready(function() {
    var isLoading = false; // 防止重复加载
    var page = 1; // 当前页码
    // 滚动事件处理
    $(window).scroll(function() {
        if (isLoading) return;

        // 检查#loading元素是否进入视口
        if (isElementInViewport($('#loading')[0])) {
            loadMoreData();
        }
    });

    // 检测元素是否进入视口
    function isElementInViewport(el) {
        var rect = el.getBoundingClientRect();
        return (
            rect.top <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.bottom >= 0
        );
    }

    // 加载更多数据
    function loadMoreData() {        
        isLoading = true;
        $('#loading').show();
        $.ajax({
            url: '/?a=page',
            type: 'GET',
            data: { p: page },
            success: function(response) {
                page++;
                $('#content').append('<div class="loadData">' + encodeApiResult(response) + '</div>');
                if(page > 10 || response == "no" ){
                    $('#loading').text(' ').off('click');              
                    $(window).off('scroll');
                }             
            },
            error: function() {
                $('#loading').text('load err').click(loadMoreData);
            },
            complete: function() {
                isLoading = false;
            }
        });
    }
    // 初始加载第一页
    loadMoreData();
});  
    $.get("/?a=index&v=<?php echo time(); ?>",{ },function(result){
        //console.log(result);
    });
</script>

<?php
  require_once( "foot.php");
?>