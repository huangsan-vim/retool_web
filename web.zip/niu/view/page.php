
<?php $cfg = require FUNC_DIR.'config.php';  ?>
<div class="caption x m">
        <div><a target="<?php echo TARGET;?>" href="<?php echo mi($A['url']); ?>"><?php echo mi($A['type']); ?></a></div>
        <div class="lr"></div>
        <div><a target="<?php echo TARGET;?>" href="<?php echo mi($A['url']); ?>"><?php echo mi("更多>>"); ?></a></div>
    </div>
    <div class="vlist layui-row layui-col-space10">   
<?php                            

    $ads = getad(5);  
    foreach($ads as $k=>$v){
        echo $v;
    }
            
            
    $arr = $db->query($A['sql']);   
    foreach($arr as $k=>$t){  
        
     if($t['id'] < OLDID){
        $imghost = "https://play.dzspyw.com";
    }else{
        $imghost =  $cfg['imghost'];
    }
            
?>
            <div class="vone layui-col-sm4 layui-col-xs6">
                <dl >
                    <dt class="preview-item">         
                        <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><img src="<?php echo $imghost. $t['litpic']; ?>"  ><i></i>
                            <div class="preview-div"></div>
                        </a>
                        <div class="view-times">
                            <div class='views'>
                            <?php
                                if($t['click'] > 1000){
                                    echo "<span></span>". number_format($t['click'], 0, '', ',') ;
                                }
                            ?>
                            </div>                                
                            <div class="date"><?php echo date("m-d",$t['inputtime']); ?></div>
                        </div>
                    </dt>
                    <dd>
                        <a target="<?php echo TARGET;?>" href="/video/show/<?php echo iden($t['id']); ?>.html" ><h3 class="showenc"><small><?php echo $t['type']; ?></small><?php echo mi($t['title']); ?></h3></a>
                    </dd>
                </dl>
            </div> 
<?php 
}
?>
  <div class="clear"></div>
</div>
<?php 
    if($A["i"] %3 == 0){
        echo '<div class="adqu">
                <div class="links-top wrapper">
                    <ul class="icon-list">
                        '.getad(4).'                        
                    </ul>
                </div>  
            </div>'; 
    }                                   
?> 