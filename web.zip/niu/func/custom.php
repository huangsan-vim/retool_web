<?php



// 获取缓存
function getCache($k){

    $cachelockFile =  FUNC_DIR."cachelock.txt";//缓存锁
    if (file_exists($cachelockFile )) {
        return false;
    }

    $dir = "../cache/".substr($k, 0, 2); //目录
    $f =  $dir."/".$k.".txt";

    if (!file_exists($f)) {
        return false;
    }

    $txt = @file_get_contents($f);
    if(!$txt){
        return false;
    }
    $data = json_decode($txt, true);

    // 检查缓存是否过期
    if (isset($data['expiry']) && time() > $data['expiry']) {
        // 缓存过期，删除缓存文件
        unlink($f);
        return false;
    }

    if( isset($data['value'])){
        return $data['value']; // 返回缓存的实际值
    }else{
        return false;
    }

    
}

// 设置缓存
function setCache($k, $v, $expiry = 3600) { // 默认有效期为 1 小时

    $cachelockFile =  FUNC_DIR."cachelock.txt";//缓存锁
    if (file_exists($cachelockFile )) {
        return false;
    }

    $cacheData = [
        'value' => $v,
        'expiry' => time() + $expiry // 计算有效期
    ];
    $dir = "../cache/".substr($k, 0, 2); //目录    
    if (!is_dir($dir)) { // 判断文件夹是否存在
        mkdir($dir, 0777, true); // 创建文件夹
    }

    file_put_contents($dir."/".$k.".txt", json_encode($cacheData));
}


//压缩JS
function compress_js($js_code) {
    // 移除单行注释
    $js_code = preg_replace('!/\*.*?\*/!s', '', $js_code);
    //$js_code = preg_replace('!//.*$!m', '', $js_code); //这个不能要会删除网址
    
    // 移除换行符和多余空格
    $js_code = str_replace(["\r\n", "\r", "\n", "\t"], '', $js_code);
    $js_code = preg_replace('/\s+/', ' ', $js_code);
    
    // 移除语句间的多余空格
    $js_code = preg_replace('/\s?([=+\-\*\/%&|^~!<>?:;,{}()$$$$])\s?/', '$1', $js_code);
    
    return $js_code;
}


//加密HTML
function b67($data) { 
    
    
    //$data = "你好 1234<a href='http://www.baidu.com'>百度一下</a>56";

    //$data = json_encode($data,JSON_UNESCAPED_UNICODE);
 
    // 3. Base64编码
    $base64 = base64_encode($data);
    
    // 4. 添加3个随机字符前缀
    $prefix = substr(md5(time()), 0, 3); // 生成3字符前缀
    $result = $prefix . $base64;
    
    return $result;
} 

 //不重复的随机数
function randNums($min, $max, $count) {
    $jg = array();
    $jg[] = 0;

    // 检查是否能生成足够的不重复的随机数
    if ($count > ($max - $min + 1)) {
        return false; // 如果要求的数量大于可生成的不重复数值总数，返回 false
    }

    while (count($jg) < $count) {
        $num = rand($min, $max);
        if (!in_array($num, $jg)) {
            $jg[] = $num;
        }
    }

    return $jg;
}


function get($k){
    $jg = "";
    if (isset($_GET[$k])) {
        $jg = $_GET[$k];
    }      
    return $jg;
}

function post($k){
    $jg = "";
    if (isset($_POST[$k])) {
        $jg = $_POST[$k];
    }      
    return $jg;
}

//获取广告
function getad($posid){   
    $jg = "";
    if($posid == 5){   $jg = array(); } //视频混插广告
    if(!AD_SHOW){    
        return $jg ;
    } 
  
    $db = new db();    
    $sql = "select * from `n_1_form_ad` where `id` = '$posid' ";
    $row = $db->query($sql);   


    if(count($row) < 1){
        echo "SQL错误" .  $sql;
        return "";
    }

    $adlist = $row[0]['adlist'];


    $adArr = json_decode($adlist,true);
 
 
    //输出结果      
    foreach($adArr as $k => $ad){ 

        if($ad[4] == "隐藏"){
            continue;
        }

        $ad['id'] = $posid;
        $data = array();
        $data['img'] = $ad[1];
        $ad['url'] = $ad[2];
        $data['title'] = $ad[3];
   
     
        
        if($posid == 9){ //播放页的两个按钮
            $jg .= '<a href="'.$ad['url'].'" class="layui-btn layui-btn-success showenc onead"  adid="'.$ad['id'].'" target="_blank" rel="nofollow" style="border-color: #333;background-color: #666;">'.mi($data['title']).'</a>&nbsp;&nbsp;';
        }
        else if( $posid == 5){ //视频列表混插广告
            $jg[] = ' <div class="vone layui-col-sm4 layui-col-xs6 ">
            <dl >
                <dt class="preview-item">
                    <a href="'.$ad['url'].'" target="_blank" class="onead"  adid="'.$ad['id'].'"><img src="'.$data['img'].'" ><i></i>
                        <div class="preview-div"></div>
                    </a>
                   
                </dt>
                <dd>
                    <a href="'.$ad['url'].'" target="_blank"  class="onead"  adid="'.$ad['id'].'"><h3 class="showenc" style="color:red;">'.mi($data['title']).'</h3></a>
                </dd>
            </dl>
        </div> ';

        }else if( $posid == 8 ){//右侧浮动
            $jg .= '<li id="li_'.$ad['id']."_".$k.'">
            <img src="/static/images/icon-close.jpeg" class="spin_close"   onclick="CloseDiv(\'li_'.$ad['id']."_".$k.'\')" >
            <a href="'.$ad['url'].'" target="_blank" class="onead" adid="'.$ad['id'].'">
                <span><img  class="lazyload ol_img1" data-src="'.$data['img'].'"></span>
            </a>
            </li>';            
        }
        else if($posid == 2 || $posid == 3){ //文字-菜单上下方
            $arr = explode(",",$data['img']);
            $dd = "";
            foreach($arr as $n=>$m){
                $dd .= '<dd  class="onead"  adid="'.$ad['id'].'" ><a href="'.$ad['url'].'" target="_blank" rel="nofollow">'.mi($m).'</a></dd>';
            }

            $jg .= '  <dl class=" " >
                <dt class="onead" adid="'.$ad['id'].'" ><a href="'.$ad['url'].'" target="_blank" rel="nofollow">'.mi($data['title']).'</a></dt>
                '.$dd.'             
                </dl>
            ';
        }        
        else if($posid == 4){ //方格子APP下载按钮                                        
            $jg .= ' <li class="onead"  adid="'.$ad['id'].'">
                    <a href="'.$ad['url'].'" target="_blank" rel="nofollow"><img src="'.$data['img'].'" referrerpolicy="no-referrer" style="border-radius: 20%; display: inline;">
                        <div class="name">'.mi($data['title']).'</div><button>'.mi("立即下载").'</button>
                    </a>
                </li>
            ';          
        }        
        else{ //顶部横幅和其他

            //判断设置了高度
            $heightStr = " max-height:100px ";
            if(!empty($ad[6])){
                $heightStr = " height:".$ad[6]."px;";
            }

            $jg .= "<div class='onead' adid='".$ad['id']."'><a href='".$ad['url']."' target='_blank'><img  class='lazyload' data-src='".$data['img']."' width='100%' style='".$heightStr."'  /></a></div>";
        }       
    }
  
    return $jg;
 
}
 



 //ID加密
 function iden($id){
    return jjAes($id,"urlidpwd");
 }

  //ID解密
  function idde($id){
    return jjAesDe($id,"urlidpwd");
 }


 //aes加密
function jjAes($msg,$key="://"){ 
    $des =@ openssl_encrypt($msg,'AES-128-ECB',$key,OPENSSL_RAW_DATA);
    return bin2hex($des);
}

//aes解密
function jjAesDe($msg,$key="://"){
    return @openssl_decrypt(hex2bin($msg),'AES-128-ECB',$key, OPENSSL_RAW_DATA );
}  


//中文字符串转16进制
function jjStr2Hex($string){
    if(empty($string)) return "";
    $hex='';
    for ($i=0; $i < strlen($string); $i++){
        $hex .= dechex(ord($string[$i]));
    }
    return $hex;
  }

//16进制转中文字符串
function jjHex2Str($hex){  
 
    if(empty($hex)){
        return "";
    }
    $string='';
    for ($i=0; $i < strlen($hex)-1; $i+=2){
        $string .= chr(hexdec($hex[$i].$hex[$i+1]));
    }
    return $string;
}
  
 

//中文加密
function mi($string) {
    $result = '';
    if(empty($string)){
        return "";
    }
    // 遍历每个字符
    foreach (mb_str_split($string) as $char) {
        // 将每个字符转换为HTML实体格式
        $result .= '&#' . mb_ord($char) . ';';
    }
    return $result;
}


//数字拆分逗号
function format_number_manual($number) {
    $number_str = strrev($number);
    $formatted_str = '';
    for ($i = 0; $i < strlen($number_str); $i++) {
        if ($i > 0 && $i % 3 == 0) {
            $formatted_str .= ',';
        }
        $formatted_str .= $number_str[$i];
    }
    return strrev($formatted_str);
}

//获取访客IP
function ip() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        $ipArray = explode(',', $ip);
        $ip = trim($ipArray[0]); // 取第一个IP，防止伪造
    } elseif (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return filter_var($ip, FILTER_VALIDATE_IP) ?: '0.0.0.0';
}

 

//获取我的主域名
function CurrentDomain(): string {
    // 1. 获取HTTP_HOST（自动处理了不带端口的情况）
    $host = $_SERVER['HTTP_HOST'] ?? '';
    
    // 2. 简单去除端口部分（如果有的话）
    $host = strpos($host, ':') !== false 
        ? substr($host, 0, strpos($host, ':')) 
        : $host;

    return ltrim($host,"www.");
}

//删除目录
function safeEmptyDirectory($dir) {
    // 1. 路径安全检查
    $dir = realpath($dir);
    if (!$dir || !is_dir($dir)) {
        throw new InvalidArgumentException('目录不存在');
    }

    // 2. 重要目录保护
    $protected = ['/', '/root', '/etc', __DIR__];
    if (in_array($dir, $protected)) {
        throw new RuntimeException('禁止操作系统目录');
    }

    // 3. 遍历删除
    $iterator = new RecursiveDirectoryIterator(
        $dir, 
        FilesystemIterator::SKIP_DOTS
    );
    
    foreach (new RecursiveIteratorIterator($iterator, RecursiveIteratorIterator::CHILD_FIRST) as $file) {
        try {
            $file->isDir() ? rmdir($file) : unlink($file);
        } catch (Exception $e) {
            error_log("删除失败: {$file->getPathname()} - " . $e->getMessage());
        }
    }

    return true;
}

//分批删除
function deleteFolderLimited($dir, $limit = 10000, &$count = 0) {
    if (!file_exists($dir)) return true;

    if (!is_dir($dir)) {
        $count++;
        return ($count > $limit) ? false : unlink($dir);
    }

    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;

        $path = $dir . DIRECTORY_SEPARATOR . $item;

        if (is_dir($path)) {
            if (!deleteFolderLimited($path, $limit, $count)) {
                return false; // 超过限制，中断
            }
        } else {
            $count++;
            if ($count > $limit) return false;
            unlink($path);
        }
    }

    $count++;
    return ($count > $limit) ? false : rmdir($dir);
}