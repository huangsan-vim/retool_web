<?php
// 配置文件
// 生成时间: 2025-07-09 02:38:00
return array (
  'imghost' => 'https://play.aggarwalpolyfab.com',
  'videohost' => 'https://play.aggarwalpolyfab.com',
  'contat' => '商务合作邮箱：okys888888@gmail.com',
  'qjtjdm' => '&lt;script&gt;
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement(&quot;script&quot;);
  hm.src = &quot;https://hm.baidu.com/hm.js?180c87d138b2140199bdd7216d472864&quot;;
  var s = document.getElementsByTagName(&quot;script&quot;)[0]; 
  s.parentNode.insertBefore(hm, s);
})();
&lt;/script&gt;',
  'fabu' => '  &lt;span id=&quot;thisUrlID&quot;&gt;https://okys520.com&lt;/span&gt;&lt;br&gt;&lt;a data-toggle=&quot;modal&quot; onclick=&quot;copyHtmlLink();&quot; style=&quot;font-size: 1.2em;&quot;&gt;点击复制链接分享给好友&lt;/a&gt; &lt;script&gt; function copyHtmlLink() {     var textToCopy = document.getElementById(&quot;thisUrlID&quot;);     var range = document.createRange();     range.selectNode(textToCopy);     window.getSelection().removeAllRanges();     window.getSelection().addRange(range);     document.execCommand(&quot;copy&quot;);     window.getSelection().removeAllRanges();     alert(&quot;分享链接已复制&quot;); } &lt;/script&gt;',
  'fztj' => 
  array (
  ),
);
