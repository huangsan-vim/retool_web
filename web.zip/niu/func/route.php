<?php

 
$uri = $_SERVER['REQUEST_URI'];
$uri = ltrim($uri, "/");
$get = explode("/", $uri);
$count = count($get);

//访问首页
if(isset($_GET['a']) && $_GET['a'] == "index"){
    
    $cache2 = str_replace("/cache/","/cache2/",CACHE_DIR);
    
    //查询网站配置是否变化
    $db = new db();  
    $A = $db->query("SELECT * FROM `n_site` where id = '1' ", false);
    if(count($A) < 1){
        echo "db err";
        exit;
    }
 
    //判断是否需要更新缓存
    $newCachetime = $A[0]["displayorder"];    
    $cachetimeFile =  CACHE_DIR."cachetime.txt";
    $cachelockFile =  FUNC_DIR."cachelock.txt";//缓存锁
    $oldCacheTime = "";    
    if(file_exists($cachetimeFile )){
        $oldCacheTime = file_get_contents($cachetimeFile);
    }
    //需要更新缓存
    if($oldCacheTime != $newCachetime){   
      
        //更新配置文件
        $setting = json_decode($A[0]["setting"], true) ;
        $param = $setting["param"];
        //获取分站统计        
        $fdtjArr = json_decode($param["fzdltj"], true);
        unset($param["fzdltj"]);//删除分站独立统计
        $param["fztj"] = array();      
        foreach($fdtjArr as $k=>$v){   
            $domain = trim($v[1]);         
            $param["fztj"][$domain] = $v[2]; 
            //保存JS文件
            $domain = str_replace(".","_",$domain);
            $jsFile = ROOT_DIR."static/tj/".$domain.".js";
            $jsStr = $v[2];
            $jsStr = str_replace("<script>", "", $jsStr);
            $jsStr = str_replace("</script>", "", $jsStr);
            file_put_contents($jsFile,$jsStr);               
        } 
         
        $param["imghost"] = trim($param["imghost"] );
        $param["videohost"] = trim($param["videohost"] );     
        // 汇总配置文件
        $configContent = "<?php\n// 配置文件\n// 生成时间: " . date('Y-m-d H:i:s') . "\nreturn " . var_export($param, true) . ";\n";
        // 将配置文件写入
        file_put_contents(dirname(__FILE__).DIRECTORY_SEPARATOR.'config.php', $configContent);
        
        //开启缓存锁       
        file_put_contents($cachelockFile, $newCachetime);                 

        //删掉原来的缓存文件       
        try {
            //删除文件夹
          
            //重命名
            if (is_dir(CACHE_DIR)) {
                rename(CACHE_DIR, $cache2);
            }
    
        } catch (Exception $e) {
            echo 'err: ' . $e->getMessage();
        }       
        
        
        //写入新的缓存时间
        if (!file_exists(CACHE_DIR)) {
            mkdir(CACHE_DIR, 0755, true); // 第三个参数 true 允许递归创建
            //echo "写缓存时间: ".CACHE_DIR;
        }
        file_put_contents($cachetimeFile, $newCachetime); 

        //解除缓存锁
        @unlink($cachelockFile);
    }else{
        //判断cache2是否存在，分批删除
       if (is_dir($cache2)) {
          $count = 0;
          $result = deleteFolderLimited($cache2, 1000, $count);
          //var_dump("删除",$cache2, $count);
        }
    }
    
    exit;
}
 
//视频点击量
if(isset($_GET['a']) && $_GET['a'] == "click"){
     $cfg = require FUNC_DIR.'config.php';  
    print_r($cfg);
    echo ".";
    $id = (int)get("id");
    $db = new db();  
    $sql = " update `n_1_form_video` set `click` = ( `click` +1 ) where `id` =  '$id'; ";   
    $db->query($sql, false); 
    exit;
} 

//首页分页加载
if(isset($_GET['a']) && $_GET['a'] == "page"){
    $page = $_GET['p'];  
    $db = new db();  
    $pageArr = array();

    //第一页就展示热门视频
    $pageArr[1]["i"] = 1;
    $pageArr[1]["type"] = "热门视频";
    $pageArr[1]["url"] = "/hot";
    $stime = strtotime("today midnight") - 86400 * 30; 
    
    $ads = getad(5); 
    
    $num = 24 - count($ads);
    
    $pageArr[1]["sql"] = "select `litpic`,`title`,`inputtime`,`id`,`click`,`type` from `n_1_form_video` where `zt` = 1 and inputtime > $stime order by `click` desc limit ". $num;
    
    $clickNum = rand(1000000,1100000);
    $pageArr[1]["sql"] = "select `litpic`,`title`,`inputtime`,`id`,`click`,`type` from `n_1_form_video` where `zt` = 1 and click > $clickNum order by rand() limit ". $num;

    //往后的页面展示栏目
    $T = $db->query("select count(id) as dd,type from n_1_form_video group by type order by dd desc"); 
  
    $i = 1;
    foreach($T as $k=>$v){      
        $i++;   
        $pageArr[$i]["i"] = $i;
        $pageArr[$i]["type"] = $v["type"];
        $pageArr[$i]["url"] = "/video/".jjStr2Hex($v["type"]);          
        $pageArr[$i]["sql"] = "select `litpic`,`title`,`inputtime`,`id`,`click`,`type` from `n_1_form_video` where `zt` = 1 and `type` = '".$v["type"]."' order by `id` desc limit ". $num; 
    }
    
    //超过了最大分页
    if($page > count($pageArr)){
        die("no");
    }

    //需要的字段    
    $A = $pageArr[$page];
  
    ob_start();  // 开启输出缓冲     
    require_once(VIEW_DIR."page.php");    
    $html = ob_get_contents();  // 获取缓冲区内容
    $html = b67($html);
    ob_end_clean();  // 结束输出缓冲


    echo $html;

    exit;
} 
 


 
//首页

if($get[0] == "main.html"){      
    view("index"); 
}
 
//热门
else if($get[0] == "hot" ){       
    if($count == 2){
        $_GET['page'] = ltrim($get[1], "p");
    }    
    view("hot"); 
}

//最新
else if($get[0] == "new" ){       
    if($count == 2){
        $_GET['page'] = ltrim($get[1], "p");
    }    
    view("new"); 
}

//搜索页
else if($get[0] == "find" ){
    $_GET['q'] = urldecode($get[1]) ;   
    if($count == 3){
        $_GET['page'] = ltrim($get[2], "p");
    }          
    view("find"); 
}

//视频列表
else if($get[0] == "video"){
    if($count == 2){//栏目页
        $_GET['type'] = jjHex2Str($get[1]);  
        $_GET['typeen'] =  $get[1];
        view("list"); 
    }         
    if($count == 3){//内容页    
        if($get[1] == "show"){
            $_GET['yuanid'] = rtrim($get[2], ".html") ;  
            $_GET['id'] = idde(rtrim($get[2], ".html"));   
            view("show"); 
        }else if($get[1] == "play"){
            $_GET['yuanid'] = rtrim($get[2], ".html") ;  
            $_GET['id'] = idde(rtrim($get[2], ".html"));   
            view("play"); 
        }else{//列表分页
            $_GET['type'] = jjHex2Str($get[1]);  
            $_GET['typeen'] =  $get[1];
            $_GET['page'] = ltrim($get[2], "p");
            view("list"); 
        }       
    }     
} 
//其他都是404
else{  
    header("HTTP/1.0 404 Not Found");
    echo "404";
    exit;
}
 
//加载模板
function view($template) {     
    $parentDir = dirname(__FILE__, 2);  
    if(false){   
        header("HTTP/1.1 404 Not Found");
        exit;       
    }else{
        require_once dirname(__DIR__) . '/view/top.php';
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);   
        $md5 = md5($uri);
        $old = getCache($md5);    
        if(!$old || !IS_CACHE){
          $db = new db(); 
          // 如果缓存不存在或已过期，渲染模板并缓存
          ob_start();  // 开启输出缓冲     
          require_once($parentDir."/view/" . $template . ".php");    
          require_once($parentDir."/view/foot.php"); 
          $html = ob_get_contents();  // 获取缓冲区内容 
          $html = b67($html);
          ob_end_clean();  // 结束输出缓冲
          if(IS_CACHE){
            setCache($md5, $html, 3600);// 5 minutes
          }          
        }else{
            $html = $old;
        }

        echo '<script>_("'.$html . '");</script></body></html>';      
  
        
    }
}




  
