<?php


class Pagination {
    private $totalRecords;
    private $recordsPerPage;
    private $currentPage;
    private $totalPages;

    public function __construct($totalRecords, $recordsPerPage = 10, $currentPage = 1) {
        $this->totalRecords = $totalRecords;
        $this->recordsPerPage = $recordsPerPage;
        $this->currentPage = $currentPage;

        $this->totalPages = ceil($totalRecords / $recordsPerPage);
    }

    public function getStartRecord() {
        return ($this->currentPage - 1) * $this->recordsPerPage;
    }

    public function generateLinks($baseUrl = '') {
        $links = '';

        // Previous page link
        if ($this->currentPage > 1) {
            $links .= '<a href="' . $baseUrl . 'p' . ($this->currentPage - 1) . '">&#19978;&#19968;&#39029;</a> ';
        }

        // Display the page number links (maximum of 5 links)
        $start = max(1, $this->currentPage - 2); // Ensure we don't show page less than 1
        $end = min($this->totalPages, $this->currentPage + 2); // Ensure we don't show page more than totalPages

        if ($start > 1) {
            $links .= '<a href="' . $baseUrl . 'p1">1</a> ';
            if ($start > 2) {
                $links .= '... ';
            }
        }

        for ($i = $start; $i <= $end; $i++) {
            if ($i == $this->currentPage) {
                $links .= '<a class="current">' . $i . '</a> ';
            } else {
                $links .= '<a href="' . $baseUrl . 'p' . $i . '">' . $i . '</a> ';
            }
        }

        if ($end < $this->totalPages) {
            if ($end < $this->totalPages - 1) {
                $links .= '... ';
            }
            $links .= '<a href="' . $baseUrl . 'p' . $this->totalPages . '">' . $this->totalPages . '</a> ';
        }

        // Next page link
        if ($this->currentPage < $this->totalPages) {
            $links .= '<a href="' . $baseUrl . 'p' . ($this->currentPage + 1) . '">&#19979;&#19968;&#39029;</a>';
        }

        // Adding the styles
        $css = '
<style>
    .page { text-align:center;}
    .page a { display:inline-block; padding:5px 10px; border-radius: 2px; border: 1px solid #CCCCCC; background-color: #F2F2F2; margin: 0 2px;}
    .page a.current { background-color: #FF5823;}
</style>';

        return $css . '<div class="page"> ' . $links . ' </div>';
    }
}
