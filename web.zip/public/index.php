<?php

define('IS_CACHE', true);//页面缓存
define('DB_CACHE', true);//数据缓存
define('AD_SHOW', true);//显示广告
define('OLDID', 7095);//旧资源ID
define('TARGET', "_blank");//新窗口

define('ROOT_DIR', dirname(__FILE__).DIRECTORY_SEPARATOR);//缓存目录
define('CACHE_DIR', str_replace("public","cache",dirname(__FILE__)).DIRECTORY_SEPARATOR);//缓存目录
define('FUNC_DIR', str_replace("public","niu".DIRECTORY_SEPARATOR."func",dirname(__FILE__)).DIRECTORY_SEPARATOR);//方法目录
define('VIEW_DIR', str_replace("public","niu".DIRECTORY_SEPARATOR."view",dirname(__FILE__)).DIRECTORY_SEPARATOR);//模板目录
 
require_once '../niu/vendor/autoload.php';
require_once '../niu/func/custom.php';
require_once '../niu/func/db.php';   
require_once '../niu/func/route.php'; 