<?php
echo "Current Dir: " . getcwd() . "\n";
echo "Script: " . __FILE__ . "\n";
echo "Autoload exists: " . (file_exists("../niu/vendor/autoload.php") ? "YES" : "NO") . "\n";
echo "Autoload path: " . realpath("../niu/vendor/autoload.php") . "\n";
?>
