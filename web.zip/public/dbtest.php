<?php
define("ROOT_DIR", dirname(__FILE__).DIRECTORY_SEPARATOR);
define("CACHE_DIR", str_replace("public","cache",dirname(__FILE__)).DIRECTORY_SEPARATOR);
define("FUNC_DIR", str_replace("public","niu".DIRECTORY_SEPARATOR."func",dirname(__FILE__)).DIRECTORY_SEPARATOR);
define("VIEW_DIR", str_replace("public","niu".DIRECTORY_SEPARATOR."view",dirname(__FILE__)).DIRECTORY_SEPARATOR);

echo "ROOT_DIR: " . ROOT_DIR . "\n";
echo "CACHE_DIR: " . CACHE_DIR . "\n";
echo "FUNC_DIR: " . FUNC_DIR . "\n";
echo "VIEW_DIR: " . VIEW_DIR . "\n";
echo "Autoload: " . (file_exists("../niu/vendor/autoload.php") ? "EXISTS" : "NOT FOUND") . "\n";

require_once "../niu/vendor/autoload.php";
echo "Autoload OK\n";

require_once "../niu/func/custom.php";
echo "Custom OK\n";
?>
