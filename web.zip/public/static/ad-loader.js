/**
 * 广告加载器 - 防御屏蔽
 * 使用动态加载和像素追踪
 */

(function() {
    'use strict';
    
    // 广告配置
    var adConfig = {
        enabled: true,
        trackingPixel: '/static/images/pixel.gif',
        fallbackAd: '/static/images/play.png'
    };
    
    // 防御广告拦截器检测
    function detectAdBlocker() {
        var testAd = document.createElement('div');
        testAd.innerHTML = '&nbsp;';
        testAd.className = 'adsbox ad-test';
        testAd.style.position = 'absolute';
        testAd.style.left = '-999px';
        document.body.appendChild(testAd);
        
        setTimeout(function() {
            var isBlocked = testAd.offsetHeight === 0;
            document.body.removeChild(testAd);
            
            if (isBlocked) {
                console.log('[广告] 检测到广告拦截器');
                // 可以在这里加载备用广告或显示提示
            }
        }, 100);
    }
    
    // 追踪像素加载
    function loadTrackingPixel(adId) {
        if (!adConfig.enabled) return;
        
        var pixel = new Image(1, 1);
        pixel.src = adConfig.trackingPixel + '?ad=' + adId + '&t=' + Date.now();
        pixel.style.position = 'absolute';
        pixel.style.left = '-9999px';
        pixel.onerror = function() {
            console.log('[追踪] 像素加载失败');
        };
        document.body.appendChild(pixel);
    }
    
    // 广告点击追踪
    function trackAdClick(adId, url) {
        // 发送追踪请求
        var trackUrl = '/?a=adclick&id=' + adId + '&t=' + Date.now();
        
        // 使用sendBeacon或像素
        if (navigator.sendBeacon) {
            navigator.sendBeacon(trackUrl);
        } else {
            new Image().src = trackUrl;
        }
        
        // 延迟跳转确保追踪完成
        setTimeout(function() {
            if (url && url !== '#') {
                window.open(url, '_blank');
            }
        }, 100);
        
        return false;
    }
    
    // 动态广告加载（防御拦截）
    function loadDynamicAd(containerId, adData) {
        var container = document.getElementById(containerId);
        if (!container) return;
        
        // 使用setTimeout异步加载，绕过某些拦截器
        setTimeout(function() {
            var adHtml = '<div class="dynamic-ad" data-ad-id="' + adData.id + '">';
            adHtml += '<a href="' + adData.url + '" target="_blank" onclick="return trackAdClick(' + adData.id + ', \'' + adData.url + '\')">';
            adHtml += '<img src="' + adData.image + '" alt="' + adData.title + '">';
            adHtml += '</a>';
            adHtml += '</div>';
            
            container.innerHTML = adHtml;
            
            // 加载追踪像素
            loadTrackingPixel(adData.id);
        }, Math.random() * 100);
    }
    
    // 广告懒加载（节省资源）
    function lazyLoadAds() {
        var ads = document.querySelectorAll('.onead');
        
        var observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    var adId = entry.target.getAttribute('adid');
                    if (adId) {
                        loadTrackingPixel(adId);
                        observer.unobserve(entry.target);
                    }
                }
            });
        }, {
            rootMargin: '50px'
        });
        
        ads.forEach(function(ad) {
            observer.observe(ad);
        });
    }
    
    // 初始化
    window.addEventListener('DOMContentLoaded', function() {
        // 检测广告拦截器
        detectAdBlocker();
        
        // 初始化懒加载
        if (document.querySelector('.onead')) {
            lazyLoadAds();
        }
    });
    
    // 导出API
    window.AdLoader = {
        track: trackAdClick,
        loadPixel: loadTrackingPixel,
        loadDynamic: loadDynamicAd
    };
    
})();


