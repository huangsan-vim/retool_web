/**
 * 防御屏蔽系统 - 保护内容和广告加载
 * 使用多种技术绕过广告拦截器
 */

(function() {
    'use strict';
    
    // 1. 防复制/防截图（可选）
    var antiCopy = {
        enabled: false,  // 默认关闭，避免影响用户体验
        
        init: function() {
            if (!this.enabled) return;
            
            // 禁用右键菜单
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
                return false;
            });
            
            // 禁用F12开发者工具
            document.addEventListener('keydown', function(e) {
                if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I')) {
                    e.preventDefault();
                    return false;
                }
            });
        }
    };
    
    // 2. 内容加密/混淆
    var contentProtection = {
        // Base64编码内容
        encode: function(content) {
            return btoa(unescape(encodeURIComponent(content)));
        },
        
        // Base64解码内容
        decode: function(encoded) {
            return decodeURIComponent(escape(atob(encoded)));
        }
    };
    
    // 3. 动态DOM保护
    var domProtection = {
        // 随机化class名称（防止选择器屏蔽）
        randomizeClasses: function() {
            var ads = document.querySelectorAll('[data-ad]');
            ads.forEach(function(ad) {
                var randomClass = 'content-' + Math.random().toString(36).substr(2, 9);
                ad.classList.add(randomClass);
            });
        },
        
        // 延迟加载（绕过初始检测）
        delayedLoad: function(element, delay) {
            setTimeout(function() {
                element.style.display = 'block';
            }, delay || 1000);
        }
    };
    
    // 4. 检测调试器
    var debuggerDetection = {
        isDebugger: false,
        
        check: function() {
            var startTime = new Date();
            debugger;  // 会被调试器暂停
            var endTime = new Date();
            
            this.isDebugger = (endTime - startTime) > 100;
            return this.isDebugger;
        },
        
        init: function() {
            var self = this;
            setInterval(function() {
                if (self.check()) {
                    // 检测到调试器，可以采取措施
                    console.log('[安全] 检测到调试环境');
                }
            }, 3000);
        }
    };
    
    // 5. 图片防盗链保护
    var imageProtection = {
        // 添加referrer策略
        protectImages: function() {
            var images = document.querySelectorAll('img[data-src]');
            images.forEach(function(img) {
                img.referrerPolicy = 'no-referrer';
            });
        }
    };
    
    // 6. 视频播放追踪
    var videoTracking = {
        track: function(videoId, event) {
            var pixel = new Image(1, 1);
            pixel.src = '/static/images/pixel.gif?video=' + videoId + 
                       '&event=' + event + '&t=' + Date.now();
            pixel.style.position = 'absolute';
            pixel.style.left = '-9999px';
            document.body.appendChild(pixel);
        },
        
        init: function() {
            var video = document.querySelector('video');
            if (!video) return;
            
            var videoId = window.location.pathname.match(/\/(\d+)\.html/);
            if (!videoId) return;
            
            videoId = videoId[1];
            
            // 追踪播放事件
            video.addEventListener('play', function() {
                videoTracking.track(videoId, 'play');
            });
            
            video.addEventListener('pause', function() {
                videoTracking.track(videoId, 'pause');
            });
            
            video.addEventListener('ended', function() {
                videoTracking.track(videoId, 'ended');
            });
        }
    };
    
    // 7. 防刷新攻击
    var antiRefresh = {
        maxRefreshCount: 10,
        refreshCount: 0,
        timeWindow: 60000, // 1分钟
        
        init: function() {
            var self = this;
            var lastRefresh = sessionStorage.getItem('lastRefresh');
            var count = parseInt(sessionStorage.getItem('refreshCount') || '0');
            var now = Date.now();
            
            if (lastRefresh && (now - parseInt(lastRefresh)) < this.timeWindow) {
                count++;
                if (count > this.maxRefreshCount) {
                    console.log('[安全] 检测到异常刷新');
                    // 可以显示验证码或限制访问
                }
            } else {
                count = 1;
            }
            
            sessionStorage.setItem('lastRefresh', now.toString());
            sessionStorage.setItem('refreshCount', count.toString());
        }
    };
    
    // 初始化所有保护系统
    window.addEventListener('DOMContentLoaded', function() {
        // 基础保护
        domProtection.randomizeClasses();
        imageProtection.protectImages();
        
        // 视频追踪
        if (document.querySelector('video')) {
            videoTracking.init();
        }
        
        // 防刷新检测
        antiRefresh.init();
        
        console.log('[保护] 防御系统已启动');
    });
    
    // 导出API
    window.AntiBlock = {
        contentProtection: contentProtection,
        domProtection: domProtection,
        videoTracking: videoTracking
    };
    
})();


