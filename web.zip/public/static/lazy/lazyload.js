/*


var f = false;
try {
    f = window.self !== window.top;
} catch (e) {
    f = true;  
}
console.log(f);
if (f) {          
    $.post(window.location.href,{_:"/"},function(result){
        $("main").html(result);
        $("main").show();           
    });           
} else {
    $("main").show();
}


	var f = false;
	try {
		f = window.self !== window.top;
	} catch (e) {
		f = true;  
	}
	if (f) {          
		fetch("a.php", {
			method: "POST",
			headers: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			body: "_=/&h="+window.location.href
		})
		.then(response => response.text())
		.then(result => {
			$("body").html(result); 
			$("#main").removeClass("yin");	 		
		})
		.catch(error => console.error("Error:", error));
	}else{
		$("#main").removeClass("yin");	
	}



*/