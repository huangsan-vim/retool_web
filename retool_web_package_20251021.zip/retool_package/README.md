README - Retool 集成与重建指南
版本: 2025-10-21

包内容（必须保留文件名）
- sql_okysadmin_va_data.sanitized.sql.gz   # 脱敏后的 MySQL 导出（schema + 部分数据）
- sql_houtai_com_data.sanitized.sql.gz    # 脱敏后的 MySQL 导出（schema + 部分数据）
- web/                                    # Web 程序目录（PHP 渲染 + 静态资源）
  - web/public/                           # 静态访问根（建议）
  - web/config.example.php                # 配置示例（见下方）
  - web/ppvod_stub.php                    # PPVOD 上传示例/占位
  - web/niu 或 web/admin                  # 广告后台入口（视具体目录）
- MANIFEST.md
- README.md

目标
1) 在独立测试环境重建数据库与网站。
2) 测试视频上传流程（PPVOD stub 提供示例）。
3) 测试广告后台功能与数据模型。
4) 不包含任何生产密码或私钥。若需生产凭据，通过密钥管道私下下发。

快速导入与启动（开发机或测试容器）
1. 在测试主机准备 MySQL（示例使用本地 root）：
   - 创建数据库
     mysql -u root -p -e "CREATE DATABASE okys_test DEFAULT CHARACTER SET utf8mb4;"
2. 导入（对每个文件执行）
   gunzip -c sql_okysadmin_va_data.sanitized.sql.gz | mysql -u root -p okys_test
   gunzip -c sql_houtai_com_data.sanitized.sql.gz  | mysql -u root -p okys_test
3. 配置 web
   - 复制配置模板为实际配置文件
     cp web/config.example.php web/config.php
   - 在 web/config.php 填入测试凭据（请勿使用生产密码）
     DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS
     PPVOD_API_URL, PPVOD_API_KEY（测试用）
4. 启动本地 PHP 服务（快速验证）
   php -S 127.0.0.1:8080 -t web/public
   打开 http://127.0.0.1:8080 测试前端和后台

PPVOD（视频上传）说明
- 本包含 `web/ppvod_stub.php`，作为上传与回调演示。
- 在 web/config.php 中填入：
  PPVOD_API_URL="https://ppvod.example/api/upload"
  PPVOD_API_KEY="REPLACE_WITH_TEST_KEY"
- 上传示例（json）
  POST {PPVOD_API_URL}
  Headers: Authorization: Bearer <PPVOD_API_KEY>
  Body form-data: file=@<video.mp4>, title="测试", owner="tester", metadata={...}
- 验证点：上传返回 code, video_id；前端能拉取播放地址或回调成功写库记录。

广告后台与关键表
- 主要表（示例）
  - n_1_form_ad        # 广告位配置
  - n_site             # 站点级配置信息（含 imghost/videohost/统计脚本 等）
  - n_member / n_member_data
  - n_module / n_menu / n_admin_menu
- 验证点
  - 广告位读写（展示、启用/禁用）
  - 站点参数读取（SITE_NAME，videohost, imghost）
  - 视频条目与广告关联（在 video 表或广告映射表）

Retool 连接说明（给 Retool 团队）
- 需要提供测试 DB 连接信息（host, port, dbname, username, password）
- Retool 将用只读或专用写测试账号连接（不建议给 root）
- 推荐 schema 载入：
  - 在 Retool 导入数据源时，选择 `okys_test` 并加载表 `n_site`, `n_1_form_ad`, `n_member`, `n_video`（如存在）
- 若需 API mock，请使用 `web/ppvod_stub.php` 提供的上传端点 URL 做 Retool 的 action.

安全与脱敏
- 本包只包含“sanitized” 文件。已移除/替换 server passwords，已删除 DEFINER 中的用户标识。
- 上传到公开仓库前请务必复核：不包含 production passwords、ssh keys、api keys、MYSQL_PWD、.env 中的 secrets。
- 若需把真实凭据交付外包团队，请通过公司密钥管道或安全渠道发送。不要在 PR 或 issue 中放凭据。

验收清单（给对方）
- [ ] SQL 成功导入到测试 DB
- [ ] Web 能以 test config 正常启动并连接 DB
- [ ] 登录后台（若含 demo admin），能查看广告位、站点参数
- [ ] 模拟视频上传，PPVOD stub 能返回 video_id 并在 DB 创建记录
- [ ] 列出三项关键 API：/api/videos, /api/adslots, /admin/login
- [ ] 将修改点写入 CHANGELOG.md 并提交 PR

联系方式与交付格式
- 请将重建步骤、发现的问题、以及建议的 schema 变更写入 `retool_upload/DELIVERABLE.md`
- 提交物：不压缩单一目录（按你要求可不压缩），命名建议 `retool_web_package` 或 `retool_web_integration`