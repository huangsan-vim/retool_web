retool_web_package

目的
给外部团队一个可在测试环境重建的包。包含已脱敏的数据库导出和现成的 web 源（用于部署和功能复现），便于 Retool / 集成方做开发与联调。

包内文件
- web/                          : 网站源码（PHP + 静态资源）
- retool_web.zip                : 可选的 web 打包（同 web/）
- sql_okysadmin_va_data.sanitized.sql(.gz) : 脱敏的 DB 导出
- sql_houtai_com_data.sanitized.sql(.gz)  : 脱敏的 DB 导出
- MANIFEST.md
- README.md （本文件）
- SHORT_INSTRUCTIONS.md（简化快速步骤）

快速部署步骤（示例）
1) 在测试服务器准备 PHP 主机
   unzip retool_web.zip -d /var/www/retool_web
   配置 Nginx/Apache 指向 /var/www/retool_web，PHP-FPM 或 équivalent。

2) 在测试 MySQL 导入（示例）
   mysql -u root -p -e "CREATE DATABASE retool_test DEFAULT CHARACTER SET utf8mb4;"
   gunzip -c sql_okysadmin_va_data.sanitized.sql.gz | mysql -u <test_user> -p retool_test
   gunzip -c sql_houtai_com_data.sanitized.sql.gz  | mysql -u <test_user> -p retool_test

3) 配置环境
   在测试环境的 .env 或配置文件里设置（示例）：
   PPVOD_API_URL=https://ppvod.test/api
   PPVOD_API_KEY=REPLACE_WITH_TEST_KEY

4) PPVOD 调用示例（HTTP）
   POST {PPVOD_API_URL}/upload
   Headers:
     Authorization: Bearer <PPVOD_API_KEY>
     Content-Type: multipart/form-data
   返回 200 表示上传逻辑通路可用。

验收清单
- 能访问并登录后台（使用测试账号）
- 能查看视频列表
- 上传视频接口返回 200 且能够在列表出现（或在预设存储中能找到文件）
- 广告位按 DB 中配置正常渲染
- 无 production 密钥或敏感凭据出现在包内

敏感信息与注意
- 本包只包含脱敏导出（*_sanitized*.sql 或 *.gz）。导出已删除或替换生产密码、DEFINER、MYSQL_PWD 等敏感串。
- 上传公共仓库前请再次核查：不含 production passwords、ssh keys、api keys、MYSQL_PWD、.env 中的 secrets。
- 如果需要对接线上 DB，请提供专门的测试账号（最小权限），不要提供 root 或服务器密码。

目录说明
- web/                        -> 网站源码（直接部署）
- *.sanitized.sql(.gz)        -> 可直接导入到测试 MySQL 的 SQL 导出
- README.md / MANIFEST.md     -> 本说明与清单

联络与验收回报
- 完成后请反馈：登录用户名、测试数据库名、是否能上传视频、是否能看到广告位
